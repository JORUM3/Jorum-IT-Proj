<!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Powered By &copy; Webberstreams Enterprise</p>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </footer>

    </div>
    <!-- /.container -->
<script src="tinymce/tinymce.min.js"></script>
    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
